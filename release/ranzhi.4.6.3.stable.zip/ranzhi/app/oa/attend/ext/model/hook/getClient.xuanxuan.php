<?php
if(strpos($_SERVER['HTTP_USER_AGENT'], 'easysoft/xuan.im') !== false) return 'xuanxuan';
