<?php
/**
 * The en file of announce module of RanZhi.
 *
 * @copyright   Copyright 2009-2018 青岛易软天创网络科技有限公司(QingDao Nature Easy Soft Network Technology Co,LTD, www.cnezsoft.com)
 * @license     ZPL (http://zpl.pub/page/zplv12.html)
 * @author      Yidong Wang <yidong@cnezsoft.com>
 * @package     announce 
 * @version     $Id$
 * @link        http://www.zdoo.org
 */
$lang->announce->common = 'Announce';
$lang->announce->browse = 'Browse';
$lang->announce->create = 'Create';
$lang->announce->edit   = 'Edit';
$lang->announce->view   = 'View';
$lang->announce->delete = 'Delete';
