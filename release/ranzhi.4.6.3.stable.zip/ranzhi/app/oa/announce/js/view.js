$(function()
{
    /* Load prev and next in modal. */
    $.setAjaxLoader('#ajaxModal .previous a', '#ajaxModal');
    $.setAjaxLoader('#ajaxModal .next a', '#ajaxModal');
})
